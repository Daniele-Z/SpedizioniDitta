
public class Cliente {
	private String nome;
	private String congnome;
	private String citta;
	private String indirizzo;
	private String N_Tel;
	private String numeroID;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCitta() {
		return citta;
	}
	public void setCitta(String citta) {
		this.citta = citta;
	}
	public String getCongnome() {
		return congnome;
	}
	public void setCongnome(String congnome) {
		this.congnome = congnome;
	}
	public String getN_Tel() {
		return N_Tel;
	}
	public void setN_Tel(String n_Tel) {
		N_Tel = n_Tel;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public String getNumeroID() {
		return numeroID;
	}
	public void setNumeroID(String numeroID) {
		this.numeroID = numeroID;
	}

}
